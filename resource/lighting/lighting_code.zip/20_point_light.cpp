/**
 * tutorial-20: Point Light
 * see at: http://ogldev.atspace.co.uk/www/tutorial20/tutorial20.html
 */
#include <opengl_util.h>
static GLuint VBO, IBO; // vertex buffer object and index buffer object.
static GLuint texture, textureTarget = GL_TEXTURE_2D, textureUnit = GL_TEXTURE0; // 2D texture.
static GLuint gWorld; // world view matrix.
static GLuint gWorldProjection; // world view projection matrix.
static GLuint gEyeP; // eye position.
static GLuint gSampler; // 2D texture.

// const char* pVSFileName = "shader.vs";
// const char* pFSFileName = "shader.fs";
static const int WINDOW_WIDTH = 600, WINDOW_HEIGHT = 400;
static const char *windowName = "Point Light";
static const char *textureImageName = "images/texture.png";
static float _x, _y; // mouse position.
static bool mstate = false; // mouse state.
static float scale = 0.0f;
// create a camera.
static Camera camera(vec3f(0.0f, 0.0f, -5.0f), vec3f(0.0f, 0.0f, -1.0f), vec3f(0.0f, 1.0f, 0.0f));

static void RenderScene() {
    glClear(GL_COLOR_BUFFER_BIT);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(TextureVertex), 0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(TextureVertex), (const GLvoid *)sizeof(vec3f));
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(TextureVertex), (const GLvoid *)(sizeof(vec3f)+sizeof(vec2f)));
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
    // make sure it active, and then bind.
    glActiveTexture(textureUnit);
    glBindTexture(textureTarget, texture);
    glDrawElements(GL_TRIANGLES, 12, GL_UNSIGNED_INT, 0);

    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(2);
    glutSwapBuffers();
}
static void IdleCB() {
    scale += 0.01f;
    PipeLine worldPL; // global pipeline value.
    worldPL.Scale()
           .Translate()
           .Rotate(0, scale)
           .SetupWorld(0.0f, 0.0f, 1.0f); // set origin position of World coordinate system.
    PipeLine world(worldPL); // copy construct.
    worldPL.SetupCamera(camera) // set Camera coordinate system.
           .PerspectiveProject(WINDOW_WIDTH*1.0f/WINDOW_HEIGHT, ToRadian(30.0f), 1, 100);
    
    glUniformMatrix4fv(gWorld, 1, GL_TRUE, (const GLfloat *)world.HeadAddr());
    glUniformMatrix4fv(gWorldProjection, 1, GL_TRUE, (const GLfloat *)worldPL.HeadAddr());
    glUniform3f(gEyeP, camera.GetPOS().x, camera.GetPOS().y, camera.GetPOS().z);
    glUniform1i(gSampler, textureUnit);
    
    sleep(20);
    glutPostRedisplay();
}
static void SpecialKeys(int key, int, int) {
    switch (key) {
    case GLUT_KEY_LEFT: camera.Translate(-Camera::STEP_VAL); break;
    case GLUT_KEY_RIGHT: camera.Translate(Camera::STEP_VAL); break;
    case GLUT_KEY_UP: camera.Translate(0.0f, Camera::STEP_VAL); break;
    case GLUT_KEY_DOWN: camera.Translate(0.0f, -Camera::STEP_VAL); break;
    case GLUT_KEY_PAGE_UP: camera.Translate(0.0f, 0.0f, Camera::STEP_VAL); break;
    case GLUT_KEY_PAGE_DOWN: camera.Translate(0.0f, 0.0f, -Camera::STEP_VAL); break;
    default: printf("Unknown Special Key: %d\n", key); break;
    }
}
static void FunctionKeys(unsigned char key, int x, int y) {
    int mod = glutGetModifiers();
    switch (mod) { // ALT=4, SHIFT=1, CTRL=2
    case 1: printf("SHIFT Key.\n"); break; 
    case 2: printf("CTRL Key.\n"); SpecialKeys(key, x, y); break;
    case 4: printf("ALT Key.\n"); break;
    default: printf("Unknown Key. %d::%c\n", (int)key, key); break;
    }
}
static void MotionFunc(int x, int y) {
    if(mstate) {
        camera.Rotate(0.0f, ToRadian((_y-y)*Camera::MOUSE_SENSITIVITY), ToRadian((_x-x)*Camera::MOUSE_SENSITIVITY));
        _x = x; _y = y; // update
    }
}
static void MouseFunc(int button, int state, int x, int y) {
    if(button == GLUT_LEFT_BUTTON) {
        if(state == GLUT_DOWN) {
            _x = x, _y = y; mstate = true;
        }
        else {
            mstate = false;
        }
    }
}
static void CreateIndexVertexBuffer() {
    unsigned int Indices[] = {
        0, 3, 1,
        1, 3, 2,
        2, 3, 0,
        0, 1, 2
    };
    glGenBuffers(1, &IBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Indices), Indices, GL_STATIC_DRAW);
    // vertex with texture information.
    TextureVertex Vertices[4] = {
        TextureVertex(vec3f(-1.0f, -1.0f, 0.5773f) , vec2f(0.0f, 0.0f)),
        TextureVertex(vec3f(0.0f, -1.0f, -1.15475f), vec2f(0.5f, 0.0f)),
        TextureVertex(vec3f(1.0f, -1.0f, 0.5773f)  , vec2f(1.0f, 0.0f)),
        TextureVertex(vec3f(0.0f, 1.0f, 0.0f)      , vec2f(0.5f, 1.0f))
    };
    // calculate normal vector for every triangle.
    for(unsigned int i = 0; i < sizeof(Indices)/sizeof(Indices[0]); i += 3) {
        vec3f v1 = Vertices[Indices[i+1]].pos - Vertices[Indices[i]].pos;
        vec3f v2 = Vertices[Indices[i+2]].pos - Vertices[Indices[i]].pos;
        vec3f normal = v1.Cross(v2).Normalize(); // cross product, calculate normal vector.
        Vertices[Indices[i]].normal += normal;
        Vertices[Indices[i+1]].normal += normal;
        Vertices[Indices[i+2]].normal += normal;
    }
    for(unsigned int i = 0; i < sizeof(Vertices)/sizeof(Vertices[0]); ++i) {
        Vertices[i].normal.Normalize();
    }
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices), Vertices, GL_STATIC_DRAW);
}
static void CreateTextureBuffer() {
    // generate texture object.
    glGenTextures(1, &texture);
    glBindTexture(textureTarget, texture);
    // The general function glTexParameterf control many aspects of the texture sampling operation.
    // Here we specify the filter to be used for magnification and minification.
    glTexParameterf(textureTarget, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(textureTarget, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load texture image.
    texture = SOIL_load_OGL_texture( // load an image file directly as a new OpenGL texture
        textureImageName,
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );
    /***
    another way to load texture image with low-level API of SOIL:
    int img_width, img_height;
    unsigned char* img = SOIL_load_image("texture.png", &img_width, &img_height, NULL, 0);
    glTexImage2D(textureTarget, 0, GL_RGBA, img_width, img_height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img);
    ***/
}
static void AddShader(GLuint ShaderProg, const char *pShaderText, GLenum ShaderType) {
    GLuint ShaderObj = glCreateShader(ShaderType);
    const GLchar *p[1];
    p[0] = pShaderText;
    GLint Lengths[1];
    Lengths[0] = strlen(pShaderText);
    glShaderSource(ShaderObj, 1, p, Lengths);
    glCompileShader(ShaderObj);
    glAttachShader(ShaderProg, ShaderObj);
}
static void CompileShaders() {
    GLuint ShaderProg = glCreateProgram();
    string vs, fs;
    // ReadFile(pVSFileName, vs);
    // ReadFile(pFSFileName, fs);
    vs = "#version 400\n"
"layout (location = 0) in vec3 Position;"
"layout (location = 1) in vec2 TexCoordIn;"
"layout (location = 2) in vec3 NormalIn;"
""
"uniform mat4 gWorld;"
"uniform mat4 gWorldProjection;"
""
"out vec2 TexCoord;"
"out vec3 NormalV;"
"out vec3 WorldP; /* world position. */"
""
"void main() {"
"    gl_Position = gWorldProjection * vec4(Position, 1.0);"
"    TexCoord = TexCoordIn;"
"    NormalV = (gWorld * vec4(NormalIn, 0.0)).xyz;"
"    WorldP = (gWorld * vec4(Position, 1.0)).xyz;"
"}";

    fs = "#version 400\n"
"in vec2 TexCoord;"
"in vec3 NormalV;"
"in vec3 WorldP;"
""
"uniform sampler2D gSampler;"
"uniform vec3 gEyeP;"
""
"struct BaseLight {"
"    vec3 Color;"
"    float AmbientIntensity;"
"    float DiffuseIntensity;"
"};"
"struct DirectionalLight {"
"    BaseLight Base;"
"    vec3 Direction;"
"};"
"struct Attenuation {"
"    float Constant;"
"    float Linear;"
"    float Exp;"
"};"
"struct PointLight {"
"    BaseLight Base;"
"    vec3 Position;"
"    Attenuation Atten;"
"};"
""
"const int MAX_POINT_LIGHTS = 2;"
""
"DirectionalLight gDirectionalLight;"
"PointLight gPointLights[MAX_POINT_LIGHTS];"
""
"float gSpecularIntensity = 1.0;"
"float gSpecularPower = 32.0;"
"float gNumPointLights = 2;"
""
"vec4 CalcLightInternal(BaseLight Light, vec3 LightDirection, vec3 Normal) {"
"    vec4 AmbientColor = vec4(Light.Color * Light.AmbientIntensity, 1.0f);"
"    float DiffuseFactor = dot(Normal, -LightDirection);"
"    vec4 DiffuseColor  = vec4(0, 0, 0, 0);"
"    vec4 SpecularColor = vec4(0, 0, 0, 0);"
"    if (DiffuseFactor > 0) {"
"        DiffuseColor = vec4(Light.Color * Light.DiffuseIntensity * DiffuseFactor, 1.0f);"
"        vec3 VertexToEye = normalize(gEyeP - WorldP);"
"        vec3 LightReflect = normalize(reflect(LightDirection, Normal));"
"        float SpecularFactor = dot(VertexToEye, LightReflect);"
"        if (SpecularFactor > 0) {"
"            SpecularFactor = pow(SpecularFactor, gSpecularPower);"
"            SpecularColor = vec4(Light.Color * gSpecularIntensity * SpecularFactor, 1.0f);"
"        }"
"    }"
"    return (AmbientColor + DiffuseColor + SpecularColor);"
"}"
""
"vec4 CalcDirectionalLight(vec3 Normal) {"
"    return CalcLightInternal(gDirectionalLight.Base, gDirectionalLight.Direction, Normal);"
"}"
""
"vec4 CalcPointLight(int Index, vec3 Normal) {"
"    vec3 LightDirection = WorldP - gPointLights[Index].Position;"
"    float Distance = length(LightDirection);"
"    LightDirection = normalize(LightDirection);"
"    vec4 Color = CalcLightInternal(gPointLights[Index].Base, LightDirection, Normal);"
"    float Attenuation =  gPointLights[Index].Atten.Constant +"
"                         gPointLights[Index].Atten.Linear * Distance +"
"                         gPointLights[Index].Atten.Exp * Distance * Distance;"
"    return Color / Attenuation;"
"}"
""
"void main()"
"{"
"    BaseLight base;"
"    base.Color = vec3(1.0f, 1.0f, 1.0f);"
"    base.AmbientIntensity = 0.0;"
"    base.DiffuseIntensity = 0.0;"
""
"    Attenuation atten;"
"    atten.Constant = 1.0; atten.Linear = 0.1; atten.Exp = 0.0;"
""
"    gDirectionalLight.Base = base;"
"    gDirectionalLight.Direction = vec3(0.0f, -1.0f, 0.0f);"
""

"    BaseLight pb;"
"    pb.Color = vec3(1.0f, 0.0f, 1.0f);"
"    pb.AmbientIntensity = 0.0;"
"    pb.DiffuseIntensity = 1.0;"

"    gPointLights[0].Base = pb;"
"    gPointLights[0].Position = vec3(-3, 3, -5);"
"    gPointLights[0].Atten = atten;"
"    gPointLights[1].Base = base;"
"    gPointLights[1].Position = vec3(3, 3, -5);"
"    gPointLights[1].Atten = atten;"
""
"    vec3 Normal = normalize(NormalV);"
"    vec4 TotalLight = CalcDirectionalLight(Normal);"
"    for (int i = 0 ; i < gNumPointLights; i++) {"
"        TotalLight += CalcPointLight(i, Normal);"
"    }"
"    gl_FragColor = texture2D(gSampler, TexCoord.xy) * TotalLight;"
"};";


    GLint Success = 0;
    GLchar ErrorLog[1024] = { 0 };
    AddShader(ShaderProg, vs.c_str(), GL_VERTEX_SHADER);
    AddShader(ShaderProg, fs.c_str(), GL_FRAGMENT_SHADER);
    glLinkProgram(ShaderProg);
    glGetProgramiv(ShaderProg, GL_LINK_STATUS, &Success);
    if (Success == 0) {
        glGetProgramInfoLog(ShaderProg, sizeof(ErrorLog), NULL, ErrorLog);
        fprintf(stdout, "Error linking shader program: '%s'\n", ErrorLog);
        exit(1);
    }
    glValidateProgram(ShaderProg);
    glGetProgramiv(ShaderProg, GL_VALIDATE_STATUS, &Success);
    if (!Success) {
        glGetProgramInfoLog(ShaderProg, sizeof(ErrorLog), NULL, ErrorLog);
        fprintf(stdout, "Invalid shader program: '%s'\n", ErrorLog);
        exit(1);
    }
    glUseProgram(ShaderProg);
    // initialize all uniform variables.
    gWorld = glGetUniformLocation(ShaderProg, "gWorld");
    assert(gWorld != 0xFFFFFFFF);
    gWorldProjection = glGetUniformLocation(ShaderProg, "gWorldProjection");
    assert(gWorldProjection != 0xFFFFFFFF);
    gEyeP = glGetUniformLocation(ShaderProg, "gEyeP");
    assert(gEyeP != 0xFFFFFFFF);
    gSampler = glGetUniformLocation(ShaderProg, "gSampler");
    assert(gSampler != 0xFFFFFFFF);
}
int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // GLUT_DOUBLE enables double buffering
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    glutInitWindowPosition(100, 100);
    glutCreateWindow(windowName);
    glutDisplayFunc(RenderScene); // register GLUT callback function.
    glutIdleFunc(IdleCB);
    glutSpecialFunc(SpecialKeys);
    glutKeyboardFunc(FunctionKeys);
    // glutPassiveMotionFunc(PassiveMotionFunc);
    glutMotionFunc(MotionFunc);
    glutMouseFunc(MouseFunc);
    // must be done after glut is initialized.
    GLenum res = glewInit();
    if(res != GLEW_OK) {
        fprintf(stdout, "Error: '%s'\n", glewGetErrorString(res));
        return EXIT_FAILURE;
    }
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    // enable back face culling, a common optimization used to drop triangles before the heavy process
    // of rasterization. just make it look butter.
    // see more @ http://ogldev.atspace.co.uk/www/tutorial16/tutorial16.html
    glFrontFace(GL_CW);
    glCullFace(GL_BACK);
    glEnable(GL_CULL_FACE);
    CreateIndexVertexBuffer();
    CreateTextureBuffer();
    CompileShaders();
    glutMainLoop();
    return EXIT_SUCCESS;
}
