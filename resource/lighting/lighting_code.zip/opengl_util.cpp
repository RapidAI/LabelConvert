#include <opengl_util.h>

bool ReadFile(const char* pFileName, std::string & outFile)
{
    std::ifstream f(pFileName);
    bool ret = false;
    if (f.is_open()) {
        std::string line;
        while (std::getline(f, line)) {
            outFile.append(line + '\n');
        }
        f.close();
        ret = true;
    }
    else {
        GL_UTIL_ERROR(pFileName);
    }
    return ret;
}

void sleep(int milliseconds = 1000) {
    std::chrono::milliseconds dura(milliseconds);
    std::this_thread::sleep_for(dura);
}

void mulmatf(const void * a, const void * b, void *result, 
        const int x, const int y, const int z)
{
    const float (*pa)[y] = (const float (*)[y])a;
    const float (*pb)[z] = (const float (*)[z])b;
    float pans[x][z] = {0};
    for(int i = 0; i < x; ++i) {
        for(int j = 0; j < z; ++j) {
            float num = 0.0f;
            for(int k = 0; k < y; ++k) {
                num += pa[i][k]*pb[k][j];
            }
            pans[i][j] = num;
        }
    }
    memcpy(result, pans, sizeof(float) * x * z);
}

// implements for class Camera
Camera::Camera(vec3f pos, vec3f target, vec3f up): POS(pos), TARGET(target), UP(up) {
    // initial camera.
    POS = pos; TARGET = target; UP = up;
    this->UpdateUVN();
}

Camera & Camera::Translate(float du, float dv, float dn) {
    vec3f delta(du*U.x + dv*V.x + dn*N.x, du*U.y + dv*V.y + dn*N.y, du*U.z + dv*V.z + dn*N.z);
    POS = POS + delta;
    TARGET = TARGET + delta;
    return this->UpdateUVN();
}

Camera & Camera::Rotate(float roll, float pitch, float yaw) {
    vec3f uu, vv, nn;

    uu = U, vv = V;
    U = uu * cosf(roll) - vv * sinf(roll);
    V = uu * sinf(roll) + vv * cosf(roll);

    vv = V, nn = N;
    V = vv * cosf(pitch) - nn * sinf(pitch);
    N = vv * sinf(pitch) + nn * cosf(pitch);

    nn = N, uu = U;
    N = nn * cosf(yaw) - uu * sinf(yaw);
    U = nn * sinf(yaw) + uu * cosf(yaw);

    // update target and up.
    TARGET = POS + N; UP = V;

    return this->UpdateUVN();
}

Camera & Camera::UpdateUVN() {
    // calculate the axis value of camera coordinate system.
    // N = (TARGET - POS).Normalize();
    N = (TARGET - POS).Normalize();
    U = (UP * N).Normalize();
    V = (N * U).Normalize();
    return *this;
}

mat4x4f & Camera::TransformM() {
    memset(M, 0x00, sizeof(M));
    M[0][0] = M[1][1] = M[2][2] = M[3][3] = 1.0f;
    // calculate translation transform.
    mat4x4f TranslateM = {
        1.0f, 0.0f, 0.0f, -POS.x,
        0.0f, 1.0f, 0.0f, -POS.y,
        0.0f, 0.0f, 1.0f, -POS.z,
        0.0f, 0.0f, 0.0f, 1.0f
    };
    mulmatf(TranslateM, M, M, 4, 4, 4);
    // calculate rotation transform.
    mat4x4f RotateM = {
        U.x , U.y , U.z , 0.0f,
        V.x , V.y , V.z , 0.0f,
        N.x , N.y , N.z , 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f
    };
    mulmatf(RotateM, M, M, 4, 4, 4);

    return this->M;
}

///////////////////////////////// END OF CLASS Camera ////////////////////////////////////

// implements for class PipeLine.

PipeLine::PipeLine() {
    M[0][0] = M[1][1] = M[2][2] = M[3][3] = 1.0f;
}
PipeLine::PipeLine(const mat4x4f & m) {
    memcpy(M, m, sizeof(M));
}
PipeLine::PipeLine(const PipeLine & p) {
    memcpy(M, p.M, sizeof(M));
}

PipeLine PipeLine::operator * (const PipeLine & p) {
    mat4x4f ans = {0.0f};
    mulmatf(M, p.M, ans, 4, 4, 4);
    return PipeLine(ans);
}

PipeLine & PipeLine::SetupWorld(float x, float y, float z) {
    return this->Translate(x, y, z);
}

PipeLine & PipeLine::SetupCamera(Camera & camera) {
    mulmatf(camera.UpdateUVN().TransformM(), M, M, 4, 4, 4);
    return *this;
}

PipeLine & PipeLine::Scale(float scaleX, float scaleY, float scaleZ) {
    mat4x4f ScaleM = {
        scaleX, 0.0f  , 0.0f  , 0.0f,
        0.0f  , scaleY, 0.0f  , 0.0f,  
        0.0f  , 0.0f  , scaleZ, 0.0f,
        0.0f  , 0.0f  , 0.0f  , 1.0f
    };
    mulmatf(ScaleM, M, M, 4, 4, 4);

    return *this;
}

PipeLine & PipeLine::Translate(float translateX, float translateY, float translateZ) {
    mat4x4f TranslateM = {
        1.0f, 0.0f, 0.0f, translateX,
        0.0f, 1.0f, 0.0f, translateY,
        0.0f, 0.0f, 1.0f, translateZ,
        0.0f, 0.0f, 0.0f, 1.0f
    };
    mulmatf(TranslateM, M, M, 4, 4, 4);
    return *this;
}

PipeLine & PipeLine::Rotate(float rx, float ry, float rz) {
    mat4x4f RotateMX = {
        1.0f, 0.0f    , 0.0f     , 0.0f,
        0.0f, cosf(rx), -sinf(rx), 0.0f,
        0.0f, sinf(rx), cosf(rx) , 0.0f,
        0.0f, 0.0f    , 0.0f     , 1.0f
    };
    mat4x4f RotateMY = {
        cosf(ry), 0.0f, -sinf(ry), 0.0f,
        0.0f    , 1.0f, 0.0f     , 0.0f,
        sinf(ry), 0.0f, cosf(ry) , 0.0f,
        0.0f    , 0.0f, 0.0f     , 1.0f
    };
    mat4x4f RotateMZ = {
        cosf(rz), -sinf(rz), 0.0f, 0.0f,
        sinf(rz), cosf(rz) , 0.0f, 0.0f,
        0.0f    , 0.0f     , 1.0f, 0.0f,
        0.0f    , 0.0f     , 0.0f, 1.0f
    };

    mulmatf(RotateMX, M, M, 4, 4, 4);
    mulmatf(RotateMY, M, M, 4, 4, 4);
    mulmatf(RotateMZ, M, M, 4, 4, 4);

    return *this;
}

PipeLine & PipeLine::PerspectiveProject(float ar, float alpha, float znear, float zfar) {
    mat4x4f PrespectiveM = {
        1.0f/(tanf(alpha/2.0)*ar), 0.0f                  , 0.0f                      , 0.0f,
        0.0f                     , 1.0f/(tanf(alpha/2.0)), 0.0f                      , 0.0f,
        0.0f                     , 0.0f                  , (-znear-zfar)/(znear-zfar), (2*zfar*znear)/(znear-zfar),
        0.0f                     , 0.0f                  , 1.0f                      , 0.0f
    };
    mulmatf(PrespectiveM, M, M, 4, 4, 4);
    return *this;
}

float * PipeLine::HeadAddr() {
    return &M[0][0];
}

void PipeLine::printM() {
    for(int i = 0; i < 4; ++i) {
        for(int j = 0; j < 4; ++j) {
            printf("%.2f ", M[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

///////////////////////////// END OF CLASS PipeLine. ///////////////////////////////



