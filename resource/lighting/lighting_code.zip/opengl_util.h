#ifndef __OPENGL_UTIL_H__
#define __OPENGL_UTIL_H__

#define _USE_MATH_DEFINES
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <string>
#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
using namespace std;

#include <GL/glew.h>
#include <GL/freeglut.h>

#include <SOIL.h> // (Simple OpenGL Image Loader)

#define ToRadian(x) (float)(((x) * M_PI / 180.0f))
#define ToDegree(x) (float)(((x) * 180.0f / M_PI))

#define GL_UTIL_ERROR(fmt, ...) { fprintf(stdout, "ERROR: %s:%d "#fmt"\n", __FUNCTION__, __LINE__, ##__VA_ARGS__); exit(-1); }
#define CHECK_NULL(var) { if(!(var)) { fprintf(stdout, "line %d: the value of "#var" is NULL.\n", __LINE__); exit(-1); } }

struct vec2f {
    float x, y;
    vec2f(): x(0.0f), y(0.0f) { }
    vec2f(float _x, float _y): x(_x), y(_y) { }
};

struct vec3f {
    float x, y, z;
    vec3f(): x(0.0f), y(0.0f), z(0.0f) { }
    vec3f(float _x, float _y, float _z): x(_x), y(_y), z(_z) { }
    // overload operator.
    vec3f operator + (const vec3f & t) {
        return vec3f(x+t.x, y+t.y, z+t.z);
    }
    vec3f operator - (const vec3f & t) {
        return vec3f(x-t.x, y-t.y, z-t.z);
    }
    vec3f & operator += (const vec3f & t) {
        x += t.x; y += t.y; z += t.z;
        return *this;
    }
    vec3f & operator -= (const vec3f & t) {
        x -= t.x; y -= t.y; z -= t.z;
        return *this;
    }
    // calculate cross product.
    vec3f operator * (const vec3f & t) {
        const float _x = y*t.z - z*t.y;
        const float _y = z*t.x - x*t.z;
        const float _z = x*t.y - y*t.x;
        return vec3f(_x, _y, _z);
    }
    vec3f Cross(const vec3f & t) {
        const float _x = y*t.z - z*t.y;
        const float _y = z*t.x - x*t.z;
        const float _z = x*t.y - y*t.x;
        return vec3f(_x, _y, _z);
    }
    // resize the vector.
    vec3f operator * (const float & t) {
        return vec3f(x*t, y*t, z*t);
    }
    // normalize vector.
    vec3f & Normalize() {
        const float magnitude = sqrtf(x*x+y*y+z*z);
        x /= magnitude; y /= magnitude; z /= magnitude;
        return *this;
    }
    void printV(char *name) {
        printf("%s: \n", name);
        printf("%.2f %.2f %.2f\n\n", x, y, z);
    }
};

struct vec4f {
    float x, y, z, w;
    vec4f():  x(0.0f), y(0.0f), z(0.0f), w(0.0f) { }
    vec4f(float _x, float _y, float _z, float _w): x(_x), y(_y), z(_z), w(_w) { }
    vec4f & Normalize() {
        const float magnitude = sqrtf(x*x+y*y+z*z+w*w);
        x /= magnitude; y /= magnitude; z /= magnitude; w /= magnitude;
        return *this;
    }
};

struct TextureVertex {
    vec3f pos;
    vec2f tex;
    vec3f normal;
    TextureVertex() {}
    TextureVertex(vec3f _pos, vec2f _tex): pos(_pos), tex(_tex) { normal = vec3f(0.0f, 0.0f, 0.0f); }
};

typedef float mat4x4f[4][4];
typedef float mat4x1f[4][1];
typedef float mat1x4f[1][4];

bool ReadFile(const char* pFileName, std::string & outFile);

void sleep(int milliseconds);

// multiple two float matrix a(x, y) with b(y, z), and write ans to result(x, z)
void mulmatf(const void * a, const void * b, void *result, const int x, const int y, const int z);

// class Camera is used to present UVN camera coordinates and transform matrix.
class Camera;
class Camera {
// UVN相机:
// 1：U – 这个向量从相机指向其右侧。它对应于X轴。
// 2：V – 直立时，这个向量是竖直向上的。这个向量对应于Y轴。
// 3：N – 由相机指向它的目标的向量。在一些3D的文献中也被称为'look at'。这个向量对应于Z轴。
// 
// pos is a XYZ position. this is where you are (your eye is or the camera is).
// target is the XYZ position where you want to look at.
// up is a XYZ normalized vector. quite often 0.0, 1.0, 0.0.
private:
    mat4x4f M = {{0.0f}};
    vec3f POS, TARGET, UP, U, V, N;
public:
    static constexpr float MOUSE_SENSITIVITY = 0.1f, STEP_VAL = 0.5;
    Camera(vec3f pos, vec3f target, vec3f up = vec3f(0.0f, 1.0f, 0.0));
    // camera control.
    Camera & Translate(float du = 0.0f, float dv = 0.0f, float dn = 0.0f);
    Camera & Rotate(float roll = 0.0f, float pitch = 0.0f, float yaw = 0.0f); // Radian value.
    Camera & UpdateUVN();
    mat4x4f & TransformM();
public:
    vec3f GetPOS() { return this->POS; }
    vec3f GetTARGET() { return this->TARGET; }
    vec3f GetUP() { return this->UP; }
};

// class PipeLine is used in concatenating transformations, tutorial 11.
class PipeLine;
class PipeLine {
private:
    mat4x4f M = {{0.0}};
public:
    PipeLine();
    PipeLine(const mat4x4f & m);
    PipeLine(const PipeLine & p);
    PipeLine operator * (const PipeLine & p); // dot multiply
    PipeLine & SetupWorld(float x = 0.0f, float y = 0.0f, float z = 0.0f);
    PipeLine & SetupCamera(Camera & camera);
    // world control.
    PipeLine & Scale(float scaleX = 1.0f, float scaleY = 1.0f, float scaleZ = 1.0f);
    PipeLine & Translate(float translateX = 0.0f, float translateY = 0.0f, float translateZ = 0.0f);
    PipeLine & Rotate(float rx = 0.0f, float ry = 0.0f, float rz = 0.0f); // Radian value.
    // perspective projection.
    PipeLine & PerspectiveProject(float ar, float alpha, float znear, float zfar);
    float *HeadAddr();

    void printM();
};

#endif // !! __OPENGL_UTIL_H__
