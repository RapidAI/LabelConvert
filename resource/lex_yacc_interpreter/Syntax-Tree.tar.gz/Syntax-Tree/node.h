/**
 * Copyright: He Tao, sighingnow@outlook.com
 * 2015-07-14
 */

#ifndef __NODE_H__
#define __NODE_H__

/* Node type definition. */
typedef enum {
    TYPE_CONTENT, TYPE_INDEX, TYPE_OP
} NodeEnum;

/* Operators. */
typedef struct {
    int name;
    int num;
    struct NodeTag *node[1]; // we need two child nodes under almost all cases.
} OpNode;

/* Node */
typedef struct NodeTag {
    NodeEnum type;
    union {
        int content;
        int index;
        OpNode op;
    };
} Node;

extern int memory[26];

#endif // !!! __NODE_H__
